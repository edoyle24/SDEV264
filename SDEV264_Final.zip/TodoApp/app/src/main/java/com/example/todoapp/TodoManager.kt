package com.example.todoapp

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.Instant
import java.util.Date

object TodoManager {

    @RequiresApi(Build.VERSION_CODES.O)
    private val todoList = mutableListOf(
        Todo(1, "task 1", Date.from(Instant.now())),
        Todo(2, "task 2", Date.from(Instant.now())),
        Todo(3, "task 3", Date.from(Instant.now())),
        Todo(4, "task 4", Date.from(Instant.now())),
        Todo(5, "task 5", Date.from(Instant.now())),
        Todo(6, "task 6", Date.from(Instant.now())),
        Todo(7, "task 7", Date.from(Instant.now())),
        Todo(8, "task 8", Date.from(Instant.now())),
        Todo(9, "task 9", Date.from(Instant.now())),
        Todo(10, "task 10", Date.from(Instant.now()))
    )


    @RequiresApi(Build.VERSION_CODES.O)
    fun getAllTodo() : List<Todo>{
        return todoList
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun addTodo(title : String){
        todoList.add(Todo(System.currentTimeMillis().toInt(),title, Date.from(Instant.now())))
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun deleteTodo(id : Int){
        todoList.removeIf{
            it.id==id
        }
    }

}